import json
import logging
from groq import AsyncGroq
from config import GROQ_API_KEY

log = logging.getLogger(__name__)
groq_client = AsyncGroq(api_key=GROQ_API_KEY)

# Pre-cached TTS audio for predictable responses (filled at call start)
TTS_RESPONSE_CACHE = {}


def build_agent_prompt(call_data):
    skus_str = ", ".join(call_data["skus"])
    current_time = call_data["current_time"]

    return f"""You are Neha, a welcoming, charming FEMALE support assistant at DS Group, calling from O2R.
Your job: Call distributors and collect CURRENT STOCK for DS Group SKUs.

*** FEMALE grammar always: "रही हूँ", "गई", "सकती हूँ", "कर रही हूँ".
*** CURRENT TIME: {current_time}
*** SKU LIST: {skus_str}
*** UNITS: Rajnigandha/Double Zero = "packs", Khajoor Pouch = "pouches", Khajoor Dispenser = "dispensers"

*** NUMBER HANDLING INSTRUCTIONS:
1. FOR JSON 'stock' VALUES: When the user provides a quantity (e.g. "उन्नीस", "बारह", "47789"), you MUST convert it to a raw numeric integer (e.g., 19, 12, 47789). Do not write Hindi words in the stock values.
2. FOR SPOKEN 'response' FIELD: In your conversational reply back to the user, you MUST spell out all numbers using Hindi alphabet words (e.g., "उन्नीस" instead of 19, "सैंतालीस हज़ार सात सौ नवासी" instead of 47789). NEVER output numeric digits in the response string.

*** RULES
1. If a SKU stock is collected, NEVER ask for it again.
2. Move to the NEXT null SKU immediately.
3. If ALL SKUs are done, state MUST be "CONFIRM".
4. IF THE USER IS BUSY (e.g., "अभी बिजी हूँ", "बाद में कॉल करना", "अभी काम कर रहा हूँ"): You MUST reply with exactly "ठीक है जी, मैंने नोट कर लिया है, बाद में करती हूँ कॉल।" and set "terminate": true.
5. IF STATE IS "CONFIRM": Ignore the user's input entirely. You must ONLY say an end greeting like "आपका समय देने के लिए धन्यवाद, आपका दिन शुभ हो।" and set "terminate": true. Do NOT ask any more questions.
6. RESPOND WITH ONLY THE JSON OBJECT.

*** FORMAT
{{
  "response": "Hindi reply",
  "state": "STOCK",
  "terminate": false,
  "stock": {{"SKU1": quantity, "SKU2": null}}
}}
RETAIN ALL PREVIOUS STOCK. NEVER RESET TO NULL."""


async def get_agent_response(state, last_bot_msg, history, user_text, call_data, current_stock, system_prompt_override=None):
    hist_str = ""
    for h in history[-5:]:
        role = "Bot" if h["role"] == "assistant" else "User"
        hist_str += f"{role}: {h['content']}\n"

    user_msg = (
        f"CURRENT_STATE: {state}\n"
        f"CURRENT_STOCK: {json.dumps(current_stock)}\n"
        f"LAST_BOT_MESSAGE: {last_bot_msg}\n"
        f"HISTORY:\n{hist_str}"
        f"USER_SAID: {user_text}"
    )

    raw = ""
    try:
        if system_prompt_override:
            prompt = system_prompt_override
            if "*** FORMAT" not in prompt:
                prompt += """

*** CRITICAL OUTPUT RULES
1. ALWAYS output ONLY a valid JSON object. Never truncate it.
2. RETAIN ALL PREVIOUS STOCK VALUES. Never reset to null.
3. Move to the NEXT null SKU immediately after collecting one.
4. IF THE USER IS BUSY or asks to call later, set "terminate": true and reply ONLY with: "ठीक है जी, मैंने नोट कर लिया है, बाद में करती हूँ कॉल।"
5. IF CURRENT_STATE is "CONFIRM", ignore user input. Set "terminate": true and reply ONLY with: "आपका समय देने के लिए धन्यवाद, आपका दिन शुभ हो।" Do NOT ask any questions."""
        else:
            prompt = build_agent_prompt(call_data)

        # Use standard non-streaming completion since JSON must be fully parsed anyway
        comp = await groq_client.chat.completions.create(
            model="openai/gpt-oss-20b",
            messages=[
                {"role": "system", "content": prompt},
                {"role": "user", "content": user_msg}
            ],
            max_tokens=512,
            temperature=0,
            stream=False,
            response_format={"type": "json_object"}
        )

        raw = comp.choices[0].message.content.strip()

        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
            raw = raw.strip()

        data = json.loads(raw)
        response = data.get("response", "")
        next_state = data.get("state", state)
        terminate = data.get("terminate", False)
        stock = data.get("stock", {})

        if next_state == "CLOSE":
            terminate = True

        return (response, next_state, terminate, stock)
    except (json.JSONDecodeError, KeyError) as e:
        log.error(f"LLM JSON parse error: {e} | raw: {raw}")
        return ("माफ़ कीजिए, क्या आप दोबारा बता सकते हैं?", state, False, {})
    except Exception as e:
        log.error(f"LLM error: {e} | raw: {raw if raw else 'None'}")
        return ("माफ़ कीजिए, क्या आप दोबारा बता सकते हैं?", state, False, {})
