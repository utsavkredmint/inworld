import asyncio
import audioop
import base64
import io
import json
import logging
import time
import aiohttp

try:
    import static_ffmpeg
    static_ffmpeg.add_paths()
except ImportError:
    pass

from pydub import AudioSegment
from config import INWORLD_AUTH
from core.audio import linear16_to_mulaw_8k

log = logging.getLogger(__name__)

TTS_CACHE = {}
WS_URL = "wss://api.inworld.ai/tts/v1/voice:streamBidirectional"
REST_URL = "https://api.inworld.ai/tts/v1/voice"

_ws = None
_ws_session = None
_reader_task = None
_connect_lock = asyncio.Lock()
_pending = {}
_ctx_counter = 0


def mp3_to_mulaw(mp3_bytes):
    """Decode MP3 → PCM 8kHz mono → mulaw."""
    audio = AudioSegment.from_mp3(io.BytesIO(mp3_bytes))
    audio = audio.set_channels(1).set_frame_rate(8000).set_sample_width(2)
    return audioop.lin2ulaw(audio.raw_data, 2)


async def _ensure_connected():
    global _ws, _ws_session, _reader_task
    async with _connect_lock:
        if _ws and not _ws.closed:
            if _reader_task and not _reader_task.done():
                return
            _reader_task = asyncio.create_task(_ws_reader())
            return
        if _ws_session is None or _ws_session.closed:
            _ws_session = aiohttp.ClientSession()
        _ws = await _ws_session.ws_connect(
            WS_URL,
            headers={"Authorization": f"Basic {INWORLD_AUTH}"},
            heartbeat=50
        )
        log.info("[TTS] WebSocket connected")
        _reader_task = asyncio.create_task(_ws_reader())


async def _ws_reader():
    global _ws
    try:
        async for msg in _ws:
            if msg.type == aiohttp.WSMsgType.TEXT:
                data = json.loads(msg.data)
                ctx_id = data.get("result", {}).get("contextId")
                if ctx_id and ctx_id in _pending:
                    await _pending[ctx_id].put(data)
            elif msg.type in (aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.ERROR, aiohttp.WSMsgType.CLOSE):
                break
    except Exception as e:
        log.error(f"[TTS-WS] Reader error: {e}")
    finally:
        log.warning("[TTS-WS] Reader stopped")
        _ws = None
        for q in _pending.values():
            await q.put(None)


class TTSContext:
    """Persistent TTS context for a single call. Supports streaming chunks to Plivo."""

    def __init__(self):
        self.ctx_id = None
        self.queue = None
        self.ready = False

    async def open(self):
        global _ctx_counter
        await _ensure_connected()
        if not _ws or _ws.closed:
            return False

        _ctx_counter += 1
        self.ctx_id = f"ctx-{_ctx_counter}"
        self.queue = asyncio.Queue()
        _pending[self.ctx_id] = self.queue

        try:
            await _ws.send_json({
                "create": {
                    "voiceId": "Riya",
                    "modelId": "inworld-tts-1.5-mini",
                    "sampleRateHertz": 16000,
                    "speakingRate": 1.10,
                    "autoMode": True,
                    "bufferCharThreshold": 50,
                },
                "contextId": self.ctx_id
            })
            data = await asyncio.wait_for(self.queue.get(), timeout=3)
            if data and data.get("result", {}).get("contextCreated"):
                self.ready = True
                log.info(f"[TTS-CTX] {self.ctx_id} opened")
                return True
            return False
        except Exception as e:
            log.error(f"[TTS-CTX] Open error: {e}")
            return False

    async def synthesize(self, text):
        """Non-streaming: collect all chunks, decode, return full audio."""
        if not self.ready or not _ws or _ws.closed:
            return None

        start = time.time()
        try:
            await _ws.send_json({"send_text": {"text": text}, "contextId": self.ctx_id})
            await asyncio.sleep(0.03)
            await _ws.send_json({"flush_context": {}, "contextId": self.ctx_id})

            audio_parts = []
            deadline = asyncio.get_event_loop().time() + 6
            while True:
                remaining = deadline - asyncio.get_event_loop().time()
                if remaining <= 0:
                    break
                data = await asyncio.wait_for(self.queue.get(), timeout=remaining)
                if data is None:
                    self.ready = False
                    break
                result = data.get("result", {})
                if "audioChunk" in result:
                    audio_b64 = result["audioChunk"].get("audioContent", "")
                    if audio_b64:
                        audio_parts.append(base64.b64decode(audio_b64))
                if "flushCompleted" in result:
                    break

            if not audio_parts:
                return None

            mulaw = mp3_to_mulaw(b"".join(audio_parts))
            ms = int((time.time() - start) * 1000)
            log.info(f"[TTS-CTX] {self.ctx_id} | {ms}ms | {len(mulaw)} bytes")
            return mulaw

        except asyncio.TimeoutError:
            log.warning(f"[TTS-CTX] Timeout {self.ctx_id}")
            return None
        except Exception as e:
            log.error(f"[TTS-CTX] Error: {e}")
            self.ready = False
            return None

    async def synthesize_stream(self, text, plivo_ws):
        """
        Streaming: send audio chunks to Plivo as they arrive from Inworld.
        Returns total mulaw bytes sent (for caching) or None on failure.
        """
        if not self.ready or not _ws or _ws.closed:
            return None

        start = time.time()
        first_chunk_sent = False
        mp3_buffer = b""
        all_mulaw = []

        try:
            await _ws.send_json({"send_text": {"text": text}, "contextId": self.ctx_id})
            await asyncio.sleep(0.03)
            await _ws.send_json({"flush_context": {}, "contextId": self.ctx_id})

            deadline = asyncio.get_event_loop().time() + 6
            while True:
                remaining = deadline - asyncio.get_event_loop().time()
                if remaining <= 0:
                    break
                data = await asyncio.wait_for(self.queue.get(), timeout=remaining)
                if data is None:
                    self.ready = False
                    break
                result = data.get("result", {})

                if "audioChunk" in result:
                    audio_b64 = result["audioChunk"].get("audioContent", "")
                    if audio_b64:
                        mp3_buffer += base64.b64decode(audio_b64)

                        # Try to decode accumulated MP3 and send to Plivo
                        try:
                            mulaw = mp3_to_mulaw(mp3_buffer)
                            if len(mulaw) > 0:
                                if not first_chunk_sent:
                                    ttfb = int((time.time() - start) * 1000)
                                    log.info(f"[TTS-STREAM] First audio at {ttfb}ms")
                                    first_chunk_sent = True

                                # Send to Plivo immediately
                                await plivo_ws.send_text(json.dumps({
                                    "event": "playAudio",
                                    "media": {
                                        "contentType": "audio/x-mulaw",
                                        "sampleRate": "8000",
                                        "payload": base64.b64encode(mulaw).decode()
                                    }
                                }))
                                all_mulaw.append(mulaw)
                                mp3_buffer = b""  # Reset buffer after successful decode
                        except Exception:
                            # Not enough MP3 data yet, keep buffering
                            pass

                if "flushCompleted" in result:
                    # Decode any remaining buffer
                    if mp3_buffer:
                        try:
                            mulaw = mp3_to_mulaw(mp3_buffer)
                            if len(mulaw) > 0:
                                await plivo_ws.send_text(json.dumps({
                                    "event": "playAudio",
                                    "media": {
                                        "contentType": "audio/x-mulaw",
                                        "sampleRate": "8000",
                                        "payload": base64.b64encode(mulaw).decode()
                                    }
                                }))
                                all_mulaw.append(mulaw)
                        except:
                            pass
                    break

            ms = int((time.time() - start) * 1000)
            total_bytes = sum(len(m) for m in all_mulaw)
            log.info(f"[TTS-STREAM] {self.ctx_id} | {ms}ms total | {total_bytes} bytes streamed")
            return b"".join(all_mulaw) if all_mulaw else None

        except asyncio.TimeoutError:
            log.warning(f"[TTS-STREAM] Timeout {self.ctx_id}")
            return None
        except Exception as e:
            log.error(f"[TTS-STREAM] Error: {e}")
            self.ready = False
            return None

    async def close(self):
        if self.ctx_id:
            try:
                if _ws and not _ws.closed:
                    await _ws.send_json({"close": {}, "contextId": self.ctx_id})
            except:
                pass
            _pending.pop(self.ctx_id, None)
            log.info(f"[TTS-CTX] {self.ctx_id} closed")
            self.ready = False


async def _rest_tts(text):
    headers = {"Authorization": f"Basic {INWORLD_AUTH}", "Content-Type": "application/json"}
    payload = {
        "text": text, "voice_id": "Riya", "model_id": "inworld-tts-1.5-mini",
        "audio_config": {
            "audio_encoding": "LINEAR16",
            "sample_rate_hertz": 16000,
            "language_code": "hi",
            "speaking_rate": 1.10
        }
    }
    try:
        async with aiohttp.ClientSession() as s:
            async with s.post(REST_URL, headers=headers, json=payload, timeout=aiohttp.ClientTimeout(total=10)) as r:
                if r.status == 200:
                    data = await r.json()
                    return linear16_to_mulaw_8k(base64.b64decode(data["audioContent"]))
    except:
        pass
    return None


def prepare_for_tts(text):
    text = text.replace("Bot:", "").replace("**", "").replace("order", "ऑर्डर").strip()
    text = text.replace("ईएमआई", "ई एम आई")
    text = text.replace("EMI", "ई एम आई")
    text = text.replace("2.5 Gram", "ढाई ग्राम")
    text = text.replace("2.5 gram", "ढाई ग्राम")
    text = text.replace("2.5 gm", "ढाई ग्राम")
    text = text.replace("2.5 ग्राम", "ढाई ग्राम")
    text = text.replace("17 Gram", "सत्रह ग्राम")
    text = text.replace("17 gram", "सत्रह ग्राम")
    text = text.replace("17 gm", "सत्रह ग्राम")
    text = text.replace("17 ग्राम", "सत्रह ग्राम")
    text = text.replace("Gram", "ग्राम")
    text = text.replace("packs", "पैक्स")
    text = text.replace("pouches", "पाउचेस")
    text = text.replace("dispensers", "डिस्पेंसर्स")
    text = text.replace("Double Zero", "डबल ज़ीरो")
    text = text.replace("Rajnigandha", "रजनीगंधा")
    text = text.replace("Khajoor", "खजूर")
    
    # Common brand and terms pronunciation fixes
    text = text.replace("DS Group", "डी एस ग्रुप")
    text = text.replace("O2R", "ओ टू आर")
    text = text.replace("stock", "स्टॉक")
    text = text.replace("inventory", "इन्वेंटरी")
    text = text.replace("check", "चेक")
    text = text.replace("call", "कॉल")
    text = text.replace("disturbance", "डिस्टर्बेंस")
    text = text.replace("SKU", "एस के यू")
    text = text.replace("note", "नोट")
    text = text.replace("noted", "नोट")
    
    # Remove hard breaks that cause TTS stuttering/long pauses
    text = text.replace("।", ",")
    text = text.replace(".", ",")
    return text


async def inworld_tts(text, tts_ctx=None, use_ws=True):
    """Non-streaming TTS — for cached/static responses."""
    text = prepare_for_tts(text)

    if text in TTS_CACHE:
        return TTS_CACHE[text]

    mulaw = None
    if tts_ctx and tts_ctx.ready and use_ws:
        mulaw = await tts_ctx.synthesize(text)

    if mulaw is None:
        start = time.time()
        mulaw = await _rest_tts(text)
        if mulaw:
            log.info(f"[TTS-REST] {int((time.time() - start) * 1000)}ms | {len(mulaw)} bytes")

    if mulaw:
        TTS_CACHE[text] = mulaw
    return mulaw


async def stream_tts_to_plivo(text, tts_ctx, plivo_ws):
    """
    Streaming TTS — sends audio chunks to Plivo as they arrive.
    Returns full mulaw audio (for caching). Falls back to non-streaming.
    """
    text = prepare_for_tts(text)

    if text in TTS_CACHE:
        return TTS_CACHE[text]

    mulaw = None
    if tts_ctx and tts_ctx.ready:
        mulaw = await tts_ctx.synthesize_stream(text, plivo_ws)

    if mulaw:
        TTS_CACHE[text] = mulaw
    return mulaw


async def pre_connect():
    try:
        await _ensure_connected()
        log.info("[TTS] WebSocket pre-connected")
    except Exception as e:
        log.warning(f"[TTS] Pre-connect failed: {e}")
